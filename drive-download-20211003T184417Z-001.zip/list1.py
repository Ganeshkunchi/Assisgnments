list=[1,5,9,8]
list.append(2)
a=list.count(1)
r=list.remove(1)
list.insert(6,7)
list.sort()
print(a)
print(list)
