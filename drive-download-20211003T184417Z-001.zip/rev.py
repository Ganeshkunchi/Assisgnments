no= 8951
revno = 0

while no != 0:
    new = no % 10
    revno = revno * 10 + digit
    no//= 10

print("Reverse of the number is " + str(revno))