p=int(input("enter the number\n"))
temp=p
r=0
while(p>0):
    g=p%10
    r=r*10+g
    p=p//10
if(temp==r):
    print("its  a palindrome")
else:
    print("its not a palindrome")
